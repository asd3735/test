//
//  AppDelegate.h
//  test03
//
//  Created by 吴超凡 on 2016/11/24.
//  Copyright © 2016年 吴超凡. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property(strong,nonatomic)UINavigationController *navigationController;


@end

