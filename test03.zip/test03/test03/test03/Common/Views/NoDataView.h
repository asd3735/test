//
//  NoDataView.h
//  Zhaoxie
//
//  Created by 吴筠秋 on 15/9/12.
//  Copyright (c) 2015年 吴筠秋. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NoDataView : UIView

@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *descLabel;
@property (weak, nonatomic) IBOutlet UIView *contentView;
@end
