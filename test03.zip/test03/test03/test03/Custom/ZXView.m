//
//  ZXView.m
//  zhaoxiewang
//
//  Created by iMac-jianjian on 16/6/5.
//  Copyright © 2016年 吴筠秋. All rights reserved.
//

#import "ZXView.h"

@implementation ZXView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
