//
//  JQPaddingLabel.h
//  LazyWeekendDemo
//
//  Created by 吴筠秋 on 16/11/23.
//  Copyright © 2016年 吴筠秋. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JQPaddingLabel : UILabel

@property (nonatomic, assign) UIEdgeInsets edgeInsets;

@end
