//
//  ZXImageView.m
//  zhaoxiewang
//
//  Created by 吴筠秋 on 15/11/17.
//  Copyright © 2015年 吴筠秋. All rights reserved.
//

#import "ZXImageView.h"

@implementation ZXImageView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
