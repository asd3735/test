//
//  ZXTextField.h
//  zhaoxiewang
//
//  Created by 吴筠秋 on 15/11/14.
//  Copyright © 2015年 吴筠秋. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZXTextField : UITextField

//拓展参数
@property (strong, nonatomic) NSIndexPath *indexPath;

@end
